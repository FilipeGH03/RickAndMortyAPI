import 'package:flutter/material.dart';

class Telalistapersonagens extends StatelessWidget {
  const Telalistapersonagens({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}
