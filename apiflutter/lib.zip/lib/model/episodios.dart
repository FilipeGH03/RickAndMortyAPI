class Episodio {
  int id;
  String name;
  String air_date;
  String episode;
  List characters;
  String url;

  Episodio({
    required this.id,
    required this.name,
    required this.air_date,
    required this.episode,
    required this.characters,
    required this.url,
  });
}
